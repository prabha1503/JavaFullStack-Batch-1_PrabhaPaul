package com.customers.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.customers.dao.CustomerDao;
import com.customers.model.Customers;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class CustomerService {
    
    @Autowired
    private CustomerDao customerDao;

    public String addCustomer(Customers customer) {
        customerDao.save(customer);
        return "Customer added successfully!";
    }

    public List<Customers> getAllCustomer() {
        return customerDao.findAll();
    }

    public Customers updateCustomer(String email, Customers updatedCustomer) {
        Customers existingCustomer = customerDao.findByEmail(email);
        if (existingCustomer != null) {
            existingCustomer.setCname(updatedCustomer.getCname());
            existingCustomer.setEmail(updatedCustomer.getEmail());
            customerDao.save(existingCustomer);
            return existingCustomer;
        }
        return null; // or throw an exception if preferred
    }

    public boolean deleteCustomer(Integer cid) {
        if (customerDao.existsById(cid)) {
            customerDao.deleteById(cid);
            return true;
        }
        return false;
    }
}