
package com.customers.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.customers.model.Customers;
import com.customers.service.CustomerService;


@RestController
@RequestMapping("/customer") // Base path for all endpoints
public class CustomerController {
    
    @Autowired
    private CustomerService customerService;

    @GetMapping
    public ResponseEntity<List<Customers>> getCustomerDetails() {
        List<Customers> customerList = customerService.getAllCustomer();
        if (customerList.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(customerList);
    }

    @PostMapping
    public ResponseEntity<String> addCustomerDetails(@RequestBody Customers customer) {
        String response = customerService.addCustomer(customer);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PutMapping("/{email}")
    public ResponseEntity<Customers> updateCustomerDetails(@PathVariable("email") String email, @RequestBody Customers customer) {
        Customers updatedCustomer = customerService.updateCustomer(email, customer);
        if (updatedCustomer != null) {
            return ResponseEntity.ok(updatedCustomer);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{cid}")
    public ResponseEntity<String> deleteCustomerDetails(@PathVariable("cid") Integer cid) {
        boolean isDeleted = customerService.deleteCustomer(cid);
        if (isDeleted) {
            return ResponseEntity.ok("Customer deleted successfully!");
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
